FrameworkPathOverride=$(dirname $(which mono))/../lib/mono/4.7.2-api/ dotnet build Ranch.csproj /property:Configuration=Release;
cp ./bin/Release/net472/VOEE.dll ../Assemblies/VOEE.dll;
cp ../Assemblies/VOEE.dll /home/fuck/.steam/steam/steamapps/common/RimWorld/Mods/VOEE_Ranch/Assemblies/VOEE.dll
